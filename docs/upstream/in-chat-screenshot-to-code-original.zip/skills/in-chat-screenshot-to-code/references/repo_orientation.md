# Repository Meta-Orientation

This guide provides architectural context on how this repository is structured, why certain code exists, and how to navigate the codebase cleanly without unnecessary reading.

---

## The Dual Nature of This Codebase

### 1. The Original Environment: A Decoupled Cloud Web App
This project was conceived and built as a standalone web product:
* **Frontend (`frontend/`)**: A Vite + React application providing a web UI (drag-and-drop file upload, model variant tabs, live iframes, and Settings modal).
* **Backend (`backend/`)**: A FastAPI service running an event loop over WebSockets (`ws://.../generate-code`), streaming JSON token packets to the browser.
* **Why the plumbing exists**: The backend contains route validators, CORS configs, parallel variant racers, and API key checkers (`OPENAI_API_KEY`, etc.) because in a web service, the browser and the AI model live on opposite ends of a network connection.

### 2. The Current Environment: In-Chat IDE Agent
When interacting with a user in this IDE:
* **You are both the intelligence and the runtime**: You do not need to boot the FastAPI server, configure WebSocket connections, or interact through the React UI.
* **Direct File System Access**: You write directly to local files and subfolders (`output/<project-name>/index.html`) using IDE tools.
* **Native Tooling**: You can inspect images, run Python scripts locally for asset cropping, and preview rendered sites directly with browser tools.

---

## Navigating Repository Code & Documentation

To work efficiently and avoid context bloat, load files only when their specific purpose aligns with your immediate task:

### What to Ignore During In-Chat UI Generation
* `frontend/src/*`: Web client state management (Zustand, commit trees, variant switching). Irrelevant when generating code directly into files.
* `backend/routes/generate_code.py`: WebSocket endpoint validation and connection lifecycles.
* `design-docs/commits-and-variants.md` & `variant-system.md`: Internal mechanics for running multiple LLM variants in parallel in the web UI.

### What Serves as Reference Logic
* `backend/asset_extraction.py`: Reference implementation for locating visual assets in an image and cropping them pixel-accurately with Pillow.
* `backend/preview_screenshot/`: Reference implementation for headless browser rendering and capturing screenshots.
* `backend/prompts/system_prompt.py`: The canonical source for frontend stack CDN configurations and targeted element editing techniques.

### When to Read Specific Design Docs
Only consult these documents if the user asks to modify or debug the web application itself:
* **Modifying the Agent Runner / LLM Providers**: Read [agentic-runner-refactor.md](file:///Users/redfox/Downloads/screenshot-to-code-main/design-docs/agentic-runner-refactor.md) and [agent-tool-calling-flow.md](file:///Users/redfox/Downloads/screenshot-to-code-main/design-docs/agent-tool-calling-flow.md).
* **Testing & Quality Assurance**: Read [QA.md](file:///Users/redfox/Downloads/screenshot-to-code-main/QA.md) and [TESTING.md](file:///Users/redfox/Downloads/screenshot-to-code-main/TESTING.md) for testing policies and prompt report evaluation.
