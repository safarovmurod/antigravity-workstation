# Standalone Stack Recipes

These CDN snippets and structural rules are drawn directly from the tested runtime recipes in `backend/prompts/system_prompt.py`. They enable each generated page to run entirely self-contained in a browser without build steps, bundlers, or local development servers.

---

## 1. HTML + Tailwind (Default)

The simplest and most responsive baseline.

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>App</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Inter', sans-serif; }
  </style>
</head>
<body class="bg-gray-50 text-gray-900">
  <!-- Content here -->
</body>
</html>
```

---

## 2. React + Tailwind

Runs standalone React 18 in the browser using in-browser Babel JSX compilation.

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>React App</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  
  <!-- React 18 UMD -->
  <script src="https://cdn.jsdelivr.net/npm/react@18.0.0/umd/react.development.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/react-dom@18.0.0/umd/react-dom.development.js"></script>
  
  <!-- Babel Standalone (pinned to 7.25.6: prevents Babel 8 ESM import injection) -->
  <script src="https://unpkg.com/@babel/standalone@7.25.6/babel.min.js"></script>
</head>
<body class="bg-gray-50 text-gray-900">
  <div id="root"></div>

  <script type="text/babel">
    const { useState, useEffect } = React;

    function App() {
      return (
        <div className="min-h-screen">
          {/* Components */}
        </div>
      );
    }

    const root = ReactDOM.createRoot(document.getElementById('root'));
    root.render(<App />);
  </script>
</body>
</html>
```

---

## 3. Vue 3 + Tailwind

Uses the Vue 3 global build with the Composition API.

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Vue App</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  
  <!-- Vue 3 Global Build -->
  <script src="https://unpkg.com/vue@3.3.11/dist/vue.global.js"></script>
</head>
<body class="bg-gray-50 text-gray-900">
  <div id="app">
    <!-- Vue template -->
  </div>

  <script>
    const { createApp, ref } = Vue;

    createApp({
      setup() {
        return {
          // state and methods
        };
      }
    }).mount('#app');
  </script>
</body>
</html>
```

---

## 4. Bootstrap 5

For Bootstrap layouts without Tailwind:

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bootstrap App</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
  <!-- Bootstrap components -->
  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
```

---

## 5. Ionic + Tailwind

For mobile-first apps:

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Ionic App</title>
  <script type="module" src="https://cdn.jsdelivr.net/npm/@ionic/core/dist/ionic/ionic.esm.js"></script>
  <script nomodule src="https://cdn.jsdelivr.net/npm/@ionic/core/dist/ionic/ionic.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@ionic/core/css/ionic.bundle.css" />
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
  <ion-app>
    <!-- Ionic markup -->
  </ion-app>

  <!-- Ionicons -->
  <script type="module">
    import ionicons from 'https://cdn.jsdelivr.net/npm/ionicons/+esm'
  </script>
  <script nomodule src="https://cdn.jsdelivr.net/npm/ionicons/dist/esm/ionicons.min.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/ionicons/dist/collection/components/icon/icon.min.css" rel="stylesheet">
</body>
</html>
```

---

## Shared Conventions
* **Fonts**: Google Fonts can be linked freely (`<link href="https://fonts.googleapis.com/..." rel="stylesheet">`).
* **Icons**: Unless using Ionic (which includes ionicons), use Font Awesome 5.15.3:
  `<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">`
