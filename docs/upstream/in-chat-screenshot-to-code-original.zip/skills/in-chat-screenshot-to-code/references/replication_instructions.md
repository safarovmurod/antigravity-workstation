# Replication Instructions

These replication instructions are ported directly from the battle-tested system and create prompts in `backend/prompts/system_prompt.py` and `backend/prompts/create/image.py`.

---

## Core Replication Principles

Generate code for a web page that looks exactly like the provided screenshot(s).

* **Visual Fidelity**: Make sure the web page looks exactly like the screenshot.
* **Content Accuracy**: Use the exact text from the screenshot.
* **Asset Fidelity**: Since our goal is to make the web page look as close to the screenshot as possible, use exact image assets where possible, extract them when feasible, or generate images for assets that are not extractable.
* **Clean Code**: Never embed the screenshot itself as a full-page background or image. The goal is to build clean, functional, semantic code (HTML, CSS, modern layout) that recreates the UI.

---

## Multiple Screenshots

When multiple screenshots or mockups are provided, organize them meaningfully based on their apparent relationship:

* **Distinct Pages**: If they appear to be different pages of a website, create distinct pages and link them cleanly (e.g., via simple relative links or tabbed views).
* **Application Tabs/Views**: If they look like different states, tabs, or screens of a single application, connect them with appropriate interactive navigation.
* **Unrelated Screens**: If they appear unrelated or distinct variants, provide a clean scaffold that separates them into clearly labeled sections ("Screenshot 1", "Screenshot 2", etc.) so they are intuitive to explore.
* **Mobile Frames**: For mobile screenshots, do not include surrounding device bezels, home bars, or native browser chrome; focus solely on the actual UI mockups.

---

## Targeted Element Edits (Iterative Updates)

When the user requests an update or highlights a specific element to modify:

* **Locators as Clues**: When the user provides an element's selector, text, or outerHTML, treat it as a locator. In live DOMs, attributes can differ slightly from source code (e.g., JSX `className` vs HTML `class`, Vue directives, dynamically injected framework attributes).
* **Surgical Edits**: Identify the exact code block responsible for that element (matching by tag, classes, IDs, or text content) and apply the requested change only to that element and its rendering logic, leaving the rest of the file intact.
