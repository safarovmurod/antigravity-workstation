---
name: in-chat-screenshot-to-code
description: >-
  Turn screenshots, UI mockups, Figma designs, or images into clean, standalone,
  runnable code directly within the IDE chat into local subfolders. Use whenever
  asked to build or replicate a web page or component from an image in this workspace.
---

# In-Chat Screenshot to Code

This skill provides the mental model, stack recipes, and workflows for replicating visual UI designs directly into clean, self-contained web pages within this IDE.

---

## Meta-Context & Environment

This repository was originally engineered as a client-server web app (React frontend + FastAPI WebSocket backend) because it was designed to stream generation to external browsers.

In this IDE, **you are both the intelligence and the runtime environment**:
* **Bypass Web Server Overhead**: You do not need to run Uvicorn, configure WebSockets, or manage React variant tabs.
* **Direct File Delivery**: All output is created directly on disk as standalone, runnable code targeting an isolated subfolder (by default, `./output/<project-name>/index.html`).
* **Self-Contained Pages**: Pages rely on CDN recipes so they can be opened directly by double-clicking or loading `file:///.../index.html` without build pipelines or dev servers.

---

## Generative Principles

1. **Pixel & Content Fidelity**: Treat the screenshot as the authoritative specification. Replicate typography, colors, hierarchy, and exact text content.
2. **Semantic Code Over Shortcuts**: Build real, clean HTML/CSS/Tailwind structure. Never embed screenshots as full-page images.
3. **Targeted Diffs for Iteration**: When refining an existing page, locate the exact element and apply surgical edits rather than regenerating the entire document.
4. **Autonomous Judgment**: Adapt layout patterns to ensure responsiveness and readability. If an image is occluded or missing, select clean, modern placeholders (e.g., via `https://placehold.co`) or generate matching visual assets.

---

## Reference Guides (Progressive Loading)

Load these documents as needed rather than reading the entire repository:

* **[Replication Instructions](./references/replication_instructions.md)**: Exact replication rules, multi-screenshot organization, mobile frame handling, and targeted element editing rules.
* **[Stack Recipes](./references/stack_recipes.md)**: Pinned CDN boilerplate for HTML+Tailwind, React 18 (with pinned Babel), Vue 3, Bootstrap 5, and Ionic.
* **[Repository Orientation](./references/repo_orientation.md)**: Map of the codebase explaining what is cloud webapp plumbing vs. reusable domain logic.

---

## Execution Workflow

```text
1. Intake & Stack Selection
   └── Determine framework (Tailwind, React, Vue, Bootstrap, Ionic). Default: HTML + Tailwind.

2. Workspace Setup
   └── Choose or create target subfolder: ./output/<project-name>/

3. Code Synthesis
   └── Write standalone index.html incorporating CDN boilerplate from Stack Recipes.

4. Optional Visual Verification Loop (User-Opt-In or Precision Review)
   └── If requested, open page in browser tool, capture rendering, compare against screenshot, and refine.
```

### Step 1: Intake & Stack Selection
Determine the target technology. If unspecified, default to **HTML + Tailwind** for maximum flexibility, or adopt the framework explicitly requested by the user:
* `HTML + Tailwind` (Default)
* `React + Tailwind` (Standalone React 18 + Babel)
* `Vue + Tailwind` (Standalone Vue 3 Global Build)
* `Bootstrap 5`
* `Ionic + Tailwind` (Mobile-focused)

See [Stack Recipes](./references/stack_recipes.md) for the exact `<head>` scripts and CDN configurations.

### Step 2: Workspace Setup
Isolate the generated project inside a subfolder:
```bash
./output/<project-slug>/
├── index.html
└── assets/       # Optional: local logos or images
```

### Step 3: Visual Synthesis & File Creation
1. Analyze the visual hierarchy: navigation, hero, content sections, card grids, footers, color palettes, and typography.
2. Refer to [Replication Instructions](./references/replication_instructions.md) for layout guidelines and asset extraction rules.
3. Use the `write_to_file` tool to save the standalone `index.html`.

### Step 4: Optional Visual Verification Loop
Visual self-correction is powerful but adds execution time. Keep it **optional**:
* **Fast Mode (Default)**: Generate clean code directly, present it to the user, and invite feedback.
* **Preview / Verification Mode**: When the user requests visual verification (or for particularly intricate layouts):
  1. Open the generated file in a browser session.
  2. Inspect alignment, responsive wrapping, and contrast.
  3. Apply surgical updates to `index.html` to correct any detected discrepancies.

### Step 5: Iterative Refinements
When the user asks for changes:
* Use the targeted element edit technique described in [Replication Instructions](./references/replication_instructions.md).
* Update specific blocks in `index.html` without rewriting unrelated components.
